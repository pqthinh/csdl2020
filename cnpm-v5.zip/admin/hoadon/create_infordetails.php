<?php

require_once '../../csdl/connectdb.php';
$table='db_phone.infodetail';
if(isset($_POST['save'])) {
    $id=$_POST['id'];
    $bonho=$_POST['bonho'];
    $hdh=$_POST['hdh'];
    $chip= $_POST['chip'];
    $camtr=$_POST['camtr'];
    $cams=$_POST['cams'];
    $thuonghieu=$_POST['thuonghieu'];
    $ketnoi=$_POST['ketnoi'];
    $manhinh=$_POST['manhinh'];
    $thietke=$_POST['thietke'];
    $pin=$_POST['pin'];
    $tienich=$_POST['tienich'];
    $thongtin=$_POST['thongtin'];
    $img1=$_POST['img1'];
    $img2=$_POST['img2'];
    $img3=$_POST['img3'];

    $sql="insert into $table (idinfo,memory,hedieuhanh,chip,cameratruoc,camerasau,thuonghieu,ketnoi,manhinh,thietke,thongtinpin,tienich,thongtinkhac,image1,image2,image3) 
             values('$id','$bonho','$hdh','$chip','$camtr','$cams','$thuonghieu','$ketnoi','$manhinh',"
            . "'$thietke','$pin','$tienich','$thongtin','$img1','$img2','$img3')";

    if(mysqli_query($conn, $sql)) {
        header("location: manager-infodetail.php");
        exit();
    } else {
        echo "Error creating information detail: " .$sql ."  ".mysqli_error($conn); 
    }
    mysqli_close($conn);
}
?>

<!Doctype html>
<html>
    <head>
        <title>Create a new product</title>
        <meta charset="utf8">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
        
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-header">
                        <h3>Create a new information</h3>
                    </div>
                    <p>Please fill on form and submit  </p>
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>"
                          method="POST">
                        <div class="form-group">
                            <label>ID </label>
                            <input type="text" name="id" value="mt-A-Vsmart-Joy-34/64-1" 
                                   class="form-control"  required="">
                        </div>
                        <div class="form-group">
                            <label>Memory </label>
                            <input type="text" name="bonho" 
                                   value="Ram :4 G\nBộ nhớ trong :64 G\nBộ nhớ còn lại :khoảng 50G\nBộ nhớ ngoài : Có" 
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Operator </label>
                            <input type="text" name="hdh" value="Hệ điều hành:android 9.0" 
                                   class="form-control"  required="">
                        </div>
                        <div class="form-group">
                            <label>Chip </label>
                            <input type="text" name="chip" value="Chipset: Snapdaragon 720G 8nm\nTốc đọ cpu :\nChip đồ họa	:" 
                                   class="form-control"  required="">
                        </div>
                        <div class="form-group">
                            <label>Camera -front  </label>
                            <input type="text" name="camtr" 
                                   value="Độ phân giải : 13mp\nVideo call : hình ảnh sắc nét.\nThông tin khác" 
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Camera - behind</label>
                            <input type="text" name="cams" value="Độ phân giải :Chính 48mp phụ 5mp\nQuay phim: Quay phim FullHD 1080p@30fps, Quay phim: FullHD 1080p@60fps, Quay phim FullHD: 1080p@120fps\nĐèn Flash :có\n\nChụp ảnh nâng cao : Chụp ảnh xóa phông..."
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Brand</label>
                            <input type="text" name="thuonghieu" value="Vsmart"
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Connector</label>
                            <input type="text" name="ketnoi" value="Mạng di động :SIM Wifi:GPS:Blutooth :Cổng kết nối :Jack tai nghe :Kết nối khác:"
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Screen</label>
                            <input type="text" name="manhinh" 
                                   value="Công nghệ màn hình :ips lcd\nĐộ phân giải : full hd +(10802340 px)\nMàn hình rộng : 6.3''\nMặt kính cảm ừng :Kính cường lực …"
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Design</label>
                            <input type="text" name="thietke" value="Trọng lượng: \nMàn hình : Tràn viền / Tai thỏ"
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Battery</label>
                            <input type="text" name="pin" value="Dung lượng pin:4000Ap\nThông tin pin:\nCông nghệ pin:"
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Utility</label>
                            <input type="text" name="tienich" value="Bảo  mật nâng cao:\nTính năng đặc biệt:\nGhi âm:\nRadio:\nXem phim:\nNghe nhạc:"
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>More</label>
                            <input type="text" name="thongtin" value="Thời điểm ra mắt : 1/1/2020"
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Image 1</label>
                            <input type="text" name="img1" value=""
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Image 2</label>
                            <input type="text" name="img2" value=""
                                   class="form-control" required="">
                        </div>
                        <div class="form-group">
                            <label>Image 3</label>
                            <input type="text" name="img3" value=""
                                   class="form-control" required="">
                        </div>
                        <input type="submit" name="save" class="btn btn-primary">
                        <a href="manager-infodetail.php" class="btn btn-default">Cancel</a>
                    </form>
                    
                </div>
            </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    </body>
</html>
    