<?php
?>

<html>
    <head>
        <title>thông tin</title>
    </head>
    <body>
        <div class="info">
            <div class="menu">
                <img >
                <div class="act">Thông tin</div>
                <div class="act">Thay đổi mật khẩu</div>
                <div class="act">Lịch sử</div>
                <div class="act">Giỏ hàng</div>
            </div>
            <div class="detail">
                
            </div>
        </div>
    </body>
</html>