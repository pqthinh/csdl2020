<?php
    require_once '../csdl/connectdb.php';
    session_start();
    $ten = $_SESSION['ten'];
    // add thanh vien vao danh sach khach hang
    // Lấy thông tin thành viên để thêm thành khách hàng name / birth / place / mobile / email 
    // Lấy thông tin nhân viên đang có ít khách nhất để thêm vào khách hàng
    $res_tv = mysqli_query($conn, "select * from thanhvien where ten = '".$ten."';");
    $row_tv = mysqli_fetch_array($res_tv);
    $name = $row_tv['ten'];
    $b = $row_tv['ngaysinh'];
    $e = $row_tv['email'];
    $m = $row_tv['mobile'];
    $p = $row_tv['password'];
    
    $idnv='';
    $resgetnv = mysqli_query($conn, "SELECT COUNT(*) as 'num',`idemployee` FROM `customer` GROUP BY `idemployee` ORDER BY 1 ;");
    while($row = mysqli_fetch_array($resgetnv)) {
        $idnv = $row['idemployee'];
        break;
    }
    $kiemtra = "select * from customer where email='".$e."';";
    if(mysqli_num_rows(mysqli_query($conn, $kiemtra))==0) {
        $sql = " insert into customer(name,birth,mobile,email,idemployee) values ('".$name."','".$b."','".$m."','".$e."','".$idnv."');";
        if(mysqli_query($conn, $sql)) {
            echo "Thêm khách hàng thành công";
        } else {
            echo "Lỗi trong lúc truy vấn ". mysqli_error($conn);
        }
    }
    // 
    //     
    // Lấy thông tin từ giỏ hàng     
    // 
    // add gio hang vao hoa don
    //Lấy lastID()
    $rowid= mysqli_query($conn, "select max(id) as id from customer;");
    $idcus1= mysqli_fetch_array($rowid);
    $idcus =$idcus1['id'];
    
    $id = $_GET['id']; // id thanhvien
    
    // truy vấn lấy hàng có idthanhvien = $id
    $sql_gio = "select * from giohang where id = '".$id."';";
    $res_gio = mysqli_query($conn, $sql_gio);
    while($row = mysqli_fetch_array($res_gio)) {
        $idpro = $row['idproduct'];
        $soluong = $row['soluong'];
        $sql="insert into hoadon(idcustomer,idproduct,soluong) values ($idcus,'".$idpro."',$soluong);";
        // Thay doi so luong sp trong bang products
        $soluongsp = "update products set quantity=quantity-$soluong where idproduct='".$idpro."';";
        if(mysqli_query($conn, $sql)) {
            mysqli_query($conn, $soluongsp);
            echo "Thêm 1 sp vào hoadon";
            
        }
        else {
            echo 'Lỗi thêm giỏ hàng vào hóa đơn  '.mysqli_error($conn); 
        }
    }
    
    //Xoa khoi giohang
    $result=  mysqli_query($conn, "delete from giohang where id = '".$id."'");
    if($result) {
        echo $idcus. "  ".$id;
        echo '<script> alert("Thanh toán thành công !!!");</script>';
        header("Location: ../index.php");
        exit(); 
    } else {
        echo 'Xuất hiện lỗi trong lúc xóa sp khỏi giỏ hàng : '.  mysqli_error($conn);
    }
    
    mysqli_close($conn);
?>